# Lab 2 deploy-on-k8s assignment files
